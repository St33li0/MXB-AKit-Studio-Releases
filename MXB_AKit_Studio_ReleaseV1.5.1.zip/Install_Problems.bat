<# : batch script
@echo off
setlocal EnableDelayedExpansion
cd /d "%~dp0"
title MXB A-Kit Studio -- Installation Diagnostic Tool

echo ==============================================================================
echo       MXB A-KIT STUDIO -- INSTALLATION DIAGNOSTIC DOCTOR
echo ==============================================================================
echo.
echo Running diagnostic checks on your MX Bikes installation...
echo Please wait a moment...
echo.

powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Continue'; $src = [System.IO.File]::ReadAllText('%~f0'); & ([ScriptBlock]::Create($src))"

echo.
echo ==============================================================================
echo Diagnostic finished! Press any key to exit...
echo ==============================================================================
pause >nul
exit /b %ERRORLEVEL%
#>

# ==============================================================================
# PowerShell Diagnostic Logic (Compatible with Windows PowerShell 5.1 & PS 7)
# ==============================================================================
$scriptDir = (Get-Location).Path
$reportPath = Join-Path $scriptDir "Submit_Me.txt"

$report = [System.Collections.Generic.List[string]]::new()

function Log-Message {
    param([string]$text, [string]$color = "White", [bool]$toConsole = $true)
    $report.Add($text)
    if ($toConsole) {
        Write-Host $text -ForegroundColor $color
    }
}

$arch = if ([System.Environment]::Is64BitOperatingSystem) { "64-bit" } else { "32-bit" }

Log-Message "==============================================================================" "Cyan"
Log-Message "       MXB A-KIT STUDIO -- INSTALLATION DIAGNOSTIC REPORT" "Cyan"
Log-Message "==============================================================================" "Cyan"
Log-Message "Generated: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')" "Gray"
Log-Message "Diagnostic Script Location: $scriptDir" "Gray"
Log-Message "OS: $([System.Environment]::OSVersion.VersionString) ($arch)" "Gray"
Log-Message ""

# ------------------------------------------------------------------------------
# 1. System Runtime Requirements
# ------------------------------------------------------------------------------
Log-Message "------------------------------------------------------------------------------" "Cyan"
Log-Message "[1] SYSTEM RUNTIMES & VISUAL C++ REDISTRIBUTABLES" "Cyan"
Log-Message "------------------------------------------------------------------------------" "Cyan"

$sys32 = [System.Environment]::GetFolderPath([System.Environment+SpecialFolder]::System)
$vcRuntime = Join-Path $sys32 "vcruntime140.dll"
$msvcp = Join-Path $sys32 "msvcp140.dll"

if ((Test-Path $vcRuntime) -and (Test-Path $msvcp)) {
    Log-Message "[OK] Visual C++ 2015-2022 x64 Runtimes found in System32." "Green"
} else {
    Log-Message "[WARNING] Visual C++ 2015-2022 x64 Runtime DLLs not found in System32!" "Yellow"
    Log-Message "          If MX Bikes crashes on startup, install the Microsoft Visual C++ 2015-2022 x64 Redistributable." "Yellow"
}

# ------------------------------------------------------------------------------
# 2. Locate MX Bikes Steam Installation Directory
# ------------------------------------------------------------------------------
Log-Message ""
Log-Message "------------------------------------------------------------------------------" "Cyan"
Log-Message "[2] MX BIKES GAME DIRECTORY DETECTION" "Cyan"
Log-Message "------------------------------------------------------------------------------" "Cyan"

$rawCandidateDirs = [System.Collections.Generic.List[string]]::new()

# Check current directory where bat is run
if ((Test-Path (Join-Path $scriptDir "mxbikes.exe")) -or (Test-Path (Join-Path $scriptDir "mxbikes64.exe"))) {
    $rawCandidateDirs.Add($scriptDir)
}

# Standard Steam paths
$defaultSteamPaths = @(
    "C:\Program Files (x86)\Steam\steamapps\common\MX Bikes",
    "C:\Program Files\Steam\steamapps\common\MX Bikes",
    "D:\SteamLibrary\steamapps\common\MX Bikes",
    "E:\SteamLibrary\steamapps\common\MX Bikes",
    "F:\SteamLibrary\steamapps\common\MX Bikes",
    "G:\SteamLibrary\steamapps\common\MX Bikes",
    "D:\Steam\steamapps\common\MX Bikes",
    "E:\Steam\steamapps\common\MX Bikes"
)
foreach ($p in $defaultSteamPaths) {
    if (Test-Path $p) { $rawCandidateDirs.Add($p) }
}

# Detect from Steam Registry & libraryfolders.vdf
try {
    $steamPathReg = (Get-ItemProperty -Path "HKCU:\Software\Valve\Steam" -Name "SteamPath" -ErrorAction SilentlyContinue).SteamPath
    if (-not $steamPathReg) {
        $steamPathReg = (Get-ItemProperty -Path "HKLM:\SOFTWARE\WOW6432Node\Valve\Steam" -Name "InstallPath" -ErrorAction SilentlyContinue).InstallPath
    }
    if ($steamPathReg -and (Test-Path $steamPathReg)) {
        $steamMxb = Join-Path $steamPathReg "steamapps\common\MX Bikes"
        if (Test-Path $steamMxb) { $rawCandidateDirs.Add($steamMxb) }

        $vdf = Join-Path $steamPathReg "steamapps\libraryfolders.vdf"
        if (Test-Path $vdf) {
            $vdfContent = Get-Content $vdf -Raw
            $matches = [regex]::Matches($vdfContent, '"path"\s+"([^"]+)"')
            foreach ($m in $matches) {
                $libPath = $m.Groups[1].Value.Replace("\\", "\")
                $mxbDir = Join-Path $libPath "steamapps\common\MX Bikes"
                if (Test-Path $mxbDir) { $rawCandidateDirs.Add($mxbDir) }
            }
        }
    }
} catch {}

# Deduplicate by full canonical path
$detectedMxbDirs = [System.Collections.Generic.List[string]]::new()
$seenPaths = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
foreach ($dir in $rawCandidateDirs) {
    if (Test-Path $dir) {
        $full = [System.IO.Path]::GetFullPath($dir).TrimEnd('\', '/')
        if ($seenPaths.Add($full)) {
            $detectedMxbDirs.Add($full)
        }
    }
}

if ($detectedMxbDirs.Count -eq 0) {
    Log-Message "[ERROR] Could not automatically locate your 'MX Bikes' game folder!" "Red"
    Log-Message "        Please ensure MX Bikes is installed via Steam." "Yellow"
} else {
    foreach ($mxbDir in $detectedMxbDirs) {
        Log-Message "[OK] Detected MX Bikes Game Directory: $mxbDir" "Green"
        $hasExe = (Test-Path (Join-Path $mxbDir "mxbikes.exe")) -or (Test-Path (Join-Path $mxbDir "mxbikes64.exe"))
        if ($hasExe) {
            Log-Message "     - mxbikes.exe verified present." "Gray"
        } else {
            Log-Message "     - [WARNING] mxbikes.exe not found in this folder." "Yellow"
        }
    }
}

# ------------------------------------------------------------------------------
# 3. Plugins Folder Structure & File Integrity Audit
# ------------------------------------------------------------------------------
Log-Message ""
Log-Message "------------------------------------------------------------------------------" "Cyan"
Log-Message "[3] PLUGINS FOLDER & FILE INTEGRITY AUDIT" "Cyan"
Log-Message "------------------------------------------------------------------------------" "Cyan"

$criticalIssuesCount = 0
$warningsCount = 0

if ($detectedMxbDirs.Count -eq 0) {
    Log-Message "[SKIPPED] Cannot audit plugins folder because MX Bikes directory was not detected." "Yellow"
    $criticalIssuesCount++
} else {
    foreach ($mxbDir in $detectedMxbDirs) {
        Log-Message "Auditing: $mxbDir\plugins\" "White"
        $pluginsDir = Join-Path $mxbDir "plugins"

        if (-not (Test-Path $pluginsDir)) {
            Log-Message "  [CRITICAL ERROR] 'plugins' folder does NOT exist at: $pluginsDir" "Red"
            Log-Message "                   You must create a 'plugins' folder inside your MX Bikes directory." "Yellow"
            $criticalIssuesCount++
            continue
        }

        # Check 1: Nested plugins\plugins folder (Common community mistake!)
        $nestedPlugins = Join-Path $pluginsDir "plugins"
        if (Test-Path $nestedPlugins) {
            Log-Message "  [CRITICAL ERROR] NESTED 'plugins\plugins' FOLDER DETECTED!" "Red"
            Log-Message "                   Location: $nestedPlugins" "Yellow"
            Log-Message "                   CAUSE: When extracting the zip, an extra 'plugins' folder was created inside 'plugins'." "Yellow"
            Log-Message "                   FIX: Move all files from '$nestedPlugins\' up into '$pluginsDir\' and delete the empty nested folder." "Yellow"
            $criticalIssuesCount++
        } else {
            Log-Message "  [OK] No nested 'plugins\plugins' folder detected." "Green"
        }

        # Check 2: Plugin DLL (MXB_AKit_Studio.dlo)
        $dloPath = Join-Path $pluginsDir "MXB_AKit_Studio.dlo"
        if (Test-Path $dloPath) {
            $dloItem = Get-Item $dloPath
            $dloSizeMb = [math]::Round($dloItem.Length / 1MB, 2)
            Log-Message "  [OK] MXB_AKit_Studio.dlo found ($dloSizeMb MB, Last Modified: $($dloItem.LastWriteTime))" "Green"
        } else {
            Log-Message "  [CRITICAL ERROR] 'MXB_AKit_Studio.dlo' is MISSING from $pluginsDir!" "Red"
            Log-Message "                   The main plugin file is missing. MX Bikes cannot load the tool." "Yellow"
            $criticalIssuesCount++
        }

        # Check 3: akit_studio_data folder
        $dataPath = Join-Path $pluginsDir "akit_studio_data"
        if (Test-Path $dataPath) {
            Log-Message "  [OK] 'akit_studio_data' folder found." "Green"

            # Check 3a: Font files
            $fontsDir = Join-Path $dataPath "fonts"
            $fntFile = Join-Path $fontsDir "RobotoMono-Regular.fnt"
            if (Test-Path $fntFile) {
                Log-Message "    [OK] HUD Font file found: RobotoMono-Regular.fnt" "Green"
            } else {
                Log-Message "    [WARNING] HUD Font file missing at: $fntFile" "Yellow"
                Log-Message "              Game will fallback to default font." "Yellow"
                $warningsCount++
            }

            # Check 3b: Images
            $imagesDir = Join-Path $dataPath "images"
            $imgPng = Join-Path $imagesDir "logo.png"
            $imgTga = Join-Path $imagesDir "logo.tga"
            if ((Test-Path $imgPng) -or (Test-Path $imgTga)) {
                Log-Message "    [OK] UI Logo images found." "Green"
            } else {
                Log-Message "    [WARNING] Logo image files missing in $imagesDir." "Yellow"
                $warningsCount++
            }

            # Check 3c: Per-bike bounds JSON files
            $boundsDir = Join-Path $dataPath "bike_bounds"
            if (Test-Path $boundsDir) {
                $jsonFiles = Get-ChildItem $boundsDir -Filter "*.json"
                if ($jsonFiles.Count -ge 30) {
                    Log-Message "    [OK] OEM Bike Bounds JSON files found: $($jsonFiles.Count) bikes loaded." "Green"
                } elseif ($jsonFiles.Count -gt 0) {
                    Log-Message "    [WARNING] Only $($jsonFiles.Count) JSON files found in $boundsDir (Expected 38 OEM bikes)." "Yellow"
                    $warningsCount++
                } else {
                    Log-Message "    [CRITICAL ERROR] 'bike_bounds' folder is EMPTY! (0 JSON files found)" "Red"
                    Log-Message "                     Setup advisor cannot read per-bike setup clicker limits." "Yellow"
                    $criticalIssuesCount++
                }
            } else {
                Log-Message "    [CRITICAL ERROR] 'bike_bounds' folder is MISSING at: $boundsDir" "Red"
                $criticalIssuesCount++
            }
        } else {
            Log-Message "  [CRITICAL ERROR] 'akit_studio_data' folder is MISSING from $pluginsDir!" "Red"
            Log-Message "                   You only copied the .dlo file without the data folder." "Yellow"
            Log-Message "                   FIX: Copy the entire 'akit_studio_data' folder into $pluginsDir\." "Yellow"
            $criticalIssuesCount++
        }

        # Check 4: Conflicting legacy plugins
        $legacyPlugins = @("setup_advisor.dlo", "mxb_setup_advisor.dlo", "MXB_Factory_Mechanic.dlo", "mx_setup_advisor.dlo")
        foreach ($lp in $legacyPlugins) {
            $legacyPath = Join-Path $pluginsDir $lp
            if (Test-Path $legacyPath) {
                Log-Message "  [WARNING] Found old legacy plugin: $lp" "Yellow"
                Log-Message "            We recommend deleting '$legacyPath' to avoid duplicate popups or conflicts." "Yellow"
                $warningsCount++
            }
        }
    }
}

# ------------------------------------------------------------------------------
# 4. Local Release Directory Audit (Where this script is running)
# ------------------------------------------------------------------------------
Log-Message ""
Log-Message "------------------------------------------------------------------------------" "Cyan"
Log-Message "[4] LOCAL RELEASE PACKAGE FILES AUDIT" "Cyan"
Log-Message "------------------------------------------------------------------------------" "Cyan"

$localExe = Get-ChildItem $scriptDir -Filter "MXB_AKit_Studio_Setup*.exe"
if ($localExe.Count -gt 0) {
    Log-Message "[OK] Automated Installer EXE found in release folder: $($localExe[0].Name)" "Green"
} else {
    Log-Message "[INFO] Automated Installer EXE not found in this folder." "Gray"
}

$localDlo = Join-Path $scriptDir "plugins\MXB_AKit_Studio.dlo"
if (Test-Path $localDlo) {
    Log-Message "[OK] Raw plugin files found in release folder." "Green"
}

# ------------------------------------------------------------------------------
# 5. Verdict & Summary Instructions
# ------------------------------------------------------------------------------
Log-Message ""
Log-Message "==============================================================================" "Cyan"
Log-Message "                         FINAL DIAGNOSTIC VERDICT" "Cyan"
Log-Message "==============================================================================" "Cyan"

if ($criticalIssuesCount -eq 0 -and $warningsCount -eq 0) {
    Log-Message ">> STATUS: [ PERFECT INSTALLATION ]" "Green"
    Log-Message "All files are in the exact correct folders! Launch MX Bikes and press [F6] in pits to open the Studio." "Green"
} elseif ($criticalIssuesCount -eq 0) {
    Log-Message ">> STATUS: [ OPERATIONAL WITH MINOR WARNINGS ] ($warningsCount warning(s))" "Yellow"
    Log-Message "The plugin should load, but review the warnings above." "Yellow"
} else {
    Log-Message ">> STATUS: [ INSTALLATION ISSUES DETECTED ] ($criticalIssuesCount error(s), $warningsCount warning(s))" "Red"
    Log-Message ""
    Log-Message "RECOMMENDED FIX OPTIONS:" "Yellow"
    Log-Message "------------------------" "Yellow"
    Log-Message "Option A (Automatic Fix):" "White"
    Log-Message "  1. Run the installer: MXB_AKit_Studio_Setup_V1.5.1.exe (or the Setup .exe in this folder)" "White"
    Log-Message "  2. It will automatically detect your Steam folder and install all files properly." "White"
    Log-Message ""
    Log-Message "Option B (Manual Fix):" "White"
    Log-Message "  1. Open your MX Bikes game folder: (e.g. C:\Program Files (x86)\Steam\steamapps\common\MX Bikes\)" "White"
    Log-Message "  2. Open the 'plugins' folder inside MX Bikes." "White"
    Log-Message "  3. Ensure 'MXB_AKit_Studio.dlo' is directly inside 'plugins\'." "White"
    Log-Message "  4. Ensure the 'akit_studio_data' folder is directly inside 'plugins\'." "White"
    Log-Message "  5. Ensure there is NO 'plugins\plugins\' nested folder." "White"
}

Log-Message ""
Log-Message "==============================================================================" "Cyan"
Log-Message "Report successfully saved to:" "White"
Log-Message "  $reportPath" "Yellow"
Log-Message ""
Log-Message ">> Please upload 'Submit_Me.txt' into our Discord support channel" "Cyan"
Log-Message "   so we can help guide you through the fix!" "Cyan"
Log-Message "==============================================================================" "Cyan"

# Write full report to text file
try {
    [System.IO.File]::WriteAllLines($reportPath, $report, [System.Text.Encoding]::UTF8)
} catch {
    Write-Warning "Could not save report file: $_"
}
