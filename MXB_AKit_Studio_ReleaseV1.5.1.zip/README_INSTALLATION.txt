﻿==============================================================================
               MXB A-KIT STUDIO v1.5.1 -- COMMUNITY RELEASE
==============================================================================

Thank you for downloading MXB A-Kit Studio!

------------------------------------------------------------------------------
HOW TO INSTALL (CHOOSE OPTION 1 OR OPTION 2):
------------------------------------------------------------------------------

OPTION 1: AUTOMATIC 1-CLICK INSTALLER (RECOMMENDED)
  1. Simply double-click 'MXB_AKit_Studio_Setup_V1.5.1.exe'
  2. Follow the prompt. It will auto-detect your Steam MX Bikes installation
     and install all files into the exact correct folders!

OPTION 2: MANUAL INSTALLATION
  1. Open your MX Bikes game directory:
     (Default: C:\Program Files (x86)\Steam\steamapps\common\MX Bikes\)
  2. Drag and drop the 'plugins' folder from this release directly into your
     MX Bikes directory.
  3. Ensure there is NO nested 'plugins\plugins' folder!
     The structure must be:
     MX Bikes\
       â””â”€â”€ plugins\
             â”œâ”€â”€ MXB_AKit_Studio.dlo
             â””â”€â”€ akit_studio_data\
                   â”œâ”€â”€ fonts\
                   â”œâ”€â”€ images\
                   â””â”€â”€ bike_bounds\

------------------------------------------------------------------------------
HAVING ISSUES? (DISCORD SUPPORT HELPER)
------------------------------------------------------------------------------
If the plugin is not appearing in-game, or if you're experiencing any issues:
  1. Double-click 'Install_Problems.bat' in this folder.
  2. It will audit your MX Bikes directories and detect any misplaced files.
  3. It will generate a text file: 'Submit_Me.txt'
  4. Drag and drop 'Submit_Me.txt' into our Discord support channel so we can
     instantly identify and guide you through the fix!

------------------------------------------------------------------------------
IN-GAME CONTROLS:
------------------------------------------------------------------------------
  [F6]        : Toggle Studio Window in Pits / Track
  [F5]        : Capture Live Telemetry Snapshot
  [F9]        : Export Tuned Recommended Setup (.stp)
  Live HUD    : Interactive Quick Tuning clicker buttons on screen
==============================================================================
